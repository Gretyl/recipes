# TODO

Forward-looking checklist of repo-wide next steps. Rationale and context
for each item live in `notes-<slug>.md` — notes record *why*; this file
records *what's next*.

## IMPLODE

- [ ] **Instrument unit & integration tests.** Start with a canvas-free
      slice: page-load DOM assertions, leaderboard logic
      (`isHighScore`, insertion/sort, seed-on-first-launch),
      state-machine entry/exit points that don't require `ctx`. See
      `notes-implode.md` → Deferred work → "Tests not yet authored".
- [ ] **Reconcile `window.storage` async API.** Either extend
      `shared/harness/storage-mock.ts` with async `get` / `set` /
      `delete` returning `{value: string} | null` (durable — reusable
      by future artifacts that consume the async surface), or add a
      local shim inside `src/implode/tests/`. See `notes-implode.md`
      for the observed call shape and the two reconciliation paths.
- [ ] **Decide on the `canvas` native dep** for jsdom game-loop
      integration tests. Required to make `ctx.*` calls stop throwing
      under jsdom; adds a compile step to CI. See `notes-implode.md` →
      Deferred work → "Canvas under jsdom".

## Template upstream candidates

Changes we made downstream that the `artifact-bench` template upstream
could adopt so future punches don't reinvent them. See
`notes-implode.md` → "Upstream-feedback candidates" and "Template fixes
rolled up during homing" for rationale.

- [ ] Rename `.html-validate.json` → `.htmlvalidate.json` so
      html-validate 9.x auto-discovers it.
- [ ] Add `"no-implicit-button-type": "off"` to the html-validate
      config (or scope the exemption per artifact if global hygiene is
      preferred).
- [ ] Add `passWithNoTests: true` to `vitest.config.ts` so new
      artifacts don't red CI before their first spec lands.
- [ ] Ship a committed `package-lock.json` so `npm ci` works out of the
      box.
- [ ] Ship `AGENTS.md` + paired `CLAUDE.md` (with `CLAUDE.md`
      containing only `@AGENTS.md`). The pair we shipped contains no
      artifact-specific content.
- [ ] Add `.claude/` to `.gitignore` to prevent accidental commits of
      Claude Code session state.
- [ ] Add a "Publishing" section to the template `README.md` naming
      `make build` as the publish step and `public/` as the deploy
      root. See `notes-implode.md` → "README 'Publishing' section"
      for the gap and fix.

## Housekeeping

- [ ] Consider pinning `engines` in `package.json`. CI runs Node 20
      via `.github/workflows/ci.yml`; local dev environments may be on
      newer. Pinning documents the supported range explicitly.
