# Implode

Source for **IMPLODE v1.0** — an inverted-objective submarine game
where reaching the Titan submersible's real 3346m crush depth is the
win condition and survival is failure.

- Play: <https://gretyl.maplecrew.org/implode.html>
- Gallery: <https://gretyl.maplecrew.org/>
- Authoritative behavioral spec: [docs/implode/IMPLODE-design-bible.md](docs/implode/IMPLODE-design-bible.md)

This repo uses the artifact-bench template — each artifact is a
single-file, copy-pasteable HTML page, typed, tested, and iterated on
without losing the property that makes it copy-pasteable. IMPLODE is
the current tenant; sibling artifacts (editors, replay viewers, WIP
variants) can land as peers under `src/` if and when they appear.

## Layout

```
src/<artifact-slug>/
├── artifact.html       # the shipping file, copy-pasteable
├── README.md           # what it is, current status
├── PROMPTS.md          # seed prompt + iteration log
├── notes.md            # design decisions (optional)
└── tests/              # unit.spec.ts (optional)
```

`public/` mirrors the deploy URLs exactly: `src/foo/artifact.html`
becomes `public/foo.html`, served from
`https://gretyl.maplecrew.org/foo.html`.

## Quickstart

```bash
make install   # npm install
make verify    # static checks (structure, types, html)
make test      # runtime checks (unit)
make build     # src/*/artifact.html -> public/
make ci        # verify && test && build
```

Scope to one artifact: `make verify ARTIFACT=<slug>`.

## Adding an artifact

See [docs/authoring.md](docs/authoring.md). One-paragraph version:
make a directory under `src/`, drop in `artifact.html`, write a
`README.md` and `PROMPTS.md` next to it, add an entry to
`docs/manifest.yml`. `make verify-structure` rejects an artifact
that's missing the README or PROMPTS file.

## Verifying changes

See [docs/verification.md](docs/verification.md). Two layers: fast
static checks via `make verify`, runtime jsdom checks via
`make test`. Add tests opt-in, the first time you catch a regression
you wish you'd caught automatically.

## Publishing

`make build` is the publish step. It copies each
`src/<slug>/artifact.html` to `public/<slug>.html` (see
[scripts/build.ts](scripts/build.ts)) and writes `public/index.html`
as a gallery tile page. Upload `public/` as your static web root —
`public/implode.html` becomes `https://your-host/implode.html`.

Artifacts are single-file self-contained HTML (inline `<style>`,
inline `<script>`, external references via absolute URLs). That means
the file at `public/<slug>.html` is byte-for-byte identical to
`src/<slug>/artifact.html` and is itself the unit of distribution —
hand someone that one file and they can open it in a browser tab or
paste it into Claude as an artifact.

## CI

The project ships with a GitHub Actions workflow at `.github/workflows/ci.yml` that runs the fast verify gate on every pull request and on push to `main`:

1. `npm ci`
2. `make verify` — structure + types (tsc `--checkJs`) + html-validate
3. `make test-unit` — vitest/jsdom unit specs

No browser binaries — the job completes in under a minute. End-to-end (browser) tests are planned for a future release via a lightweight rodney-based replacement; see `cookbook/notes/artifact-bench.md` "Deferred work" for status.

To run the same gate locally:

```bash
npm install && make verify && make test-unit
```

```mermaid
flowchart LR
    A[PR or push to main] --> B[npm ci]
    B --> C[make verify]
    C --> D[make test-unit]
    D --> E{Pass?}
    E -->|Yes| F[Green]
    E -->|No| G[Red]
```

