# IMPLODE design bible

Design reference for **IMPLODE** — a satirical retro submarine descent game.
Use this document to validate ports, rewrites, and expansions.

---

## Sprite Reference

[Sprite Reference Sheet](implode-sprite-reference.png)

All game entities at 6× scale for clarity. Top to bottom:

- **Submarine** at hull HP 3 (pristine), HP 2 (one crack), HP 1 (two cracks)
- **Fish** — white passive silhouettes, both facing directions
- **Sharks** — red hostile silhouettes with dorsal fin and yellow eye, both directions
- **Obstructions** — jagged polygons in wall colors at four depth zones (~500m, ~1750m, ~2500m, ~3200m)
- **HUD hull icons** — filled green (active), outlined (lost), shown at 3/3, 1/3, and 0/3
- **Water color zones** — all 8 depth zones with corresponding wall colors beneath

---

## Concept

> **The only losing move is making it back alive!**

The player holds to dive a submarine downward through narrowing ocean walls.
Releasing input lets buoyancy carry the sub back toward the surface — which is
how you **lose**. The goal is to descend as deep as possible before your hull
gives out or you reach crush depth at 3,346m (the real depth of the Titan
submersible's final ping).

Thematically, the game satirizes reckless billionaire hubris through gallows
humor. Every system reinforces the joke: waivers you must sign, milestones that
mock your choices, and a high score list sorted by shallowest death.

---

## Win & Loss Conditions

### Loss (Survival)
- The sub naturally rises due to buoyancy when the player releases input.
- At depth 0m the camera locks and the sub rises on-screen toward the waves.
- When the sub reaches near the top of the screen, a white fade begins.
- If the fade reaches full opacity, the player "survived" — the loss screen appears.
- Shame texts (random selection):
  1. "Congratulations. You have learned nothing. Your privilege is intact."
  2. "You survived. The ocean is disappointed. So is everyone on Twitter."
  3. "Against all odds, you live. Your memoir will be insufferable."

### Win (Destruction)
- The sub is destroyed by losing all 3 hull integrity points (walls, obstructions, sharks)
  OR by reaching crush depth (3,346m), which triggers sequential hull pip loss.
- Death triggers a confetti implosion animation, then the game-over screen.
- Death quips (random selection):
  1. "The ocean always wins."
  2. "Disrupted by physics."
  3. "Your legacy is bubbles."
  4. "Net worth at depth: $0."
  5. "Should've taken the yacht."
  6. "Move fast and break hulls."
  7. "Innovated too close to crush depth."

### Special: 0m Death
- If deathDepth is 0, the quip reads: "You didn't even submerge. The ocean
  didn't notice you."
- 0m scores are ineligible for the Forbes Abyss List.

---

## Physics

### Buoyancy (Nonlinear)
- Modeled as `surfaceBuoyancy / (1 + depth × 0.0006)` where surfaceBuoyancy = 0.12.
- Strongest near the surface (sub bobs up quickly if released early).
- Weakens with depth, simulating hull compression reducing displacement.

### Dive
- Player holds click/touch/spacebar/down-arrow to descend.
- DIVE_ACCEL = 0.50, applied per frame while input is held.
- Max dive velocity decreases with depth: `MAX_DIVE_VEL × (0.35 + 0.65 / (1 + depth × 0.001))`.
- At 0m: ~0.60 px/frame. At 1500m: ~0.37. At 3000m: ~0.27.
- MAX_DIVE_VEL = 0.60, MAX_RISE_VEL = 0.9.

### Horizontal Steering
- Arrow keys / A-D for keyboard. Touch position relative to sub for mobile.
- Momentum-based with 0.92 friction per frame.
- Steer acceleration = 2.2 × dt × 60 × 0.3.

### Invulnerability
- On hull hit: 1.8 seconds of invulnerability.
- Sub blinks (sin-wave phase, hidden when `sin(blinkPhase × π) > 0.3`).
- Sub is bounced horizontally away from the hit source (BOUNCE_VEL = 4).

### Damage Immunity
- The sub takes no damage at depth ≤ 0m from any source.

---

## Camera System

Three modes with smooth transitions between them:

### Normal Scroll
- Sub stays at screen Y = 30% from top (normalSubY).
- ScrollOffset moves with subVY.

### Surface Lock (depth ≤ 0)
- ScrollOffset pinned at 0.
- Sub physically rises on-screen toward the wave line at the top.
- Clamped so sub doesn't go above the screen.

### Crush Depth Lock (near 3,346m)
- When the dashed red crush-depth line reaches the lower 2/3 of the screen
  and the player is still diving, scrolling stops.
- Sub physically descends on-screen toward the red line.
- Creates a "committed diehard" moment where you watch yourself approach the end.

### Transition Recovery
- When exiting either lock (player reverses direction), the sub eases back
  to normalSubY at a proportional speed: `min(|diff|, |diff| × 0.05 + 0.3)`.
- Scrolling resumes simultaneously. No teleporting.

---

## Depth Milestones

Triggered once per game at their exact depth. Display for 3.2 seconds with
fade-in (0.5s) and fade-out (0.5s). Rendered centered on screen in yellow
VT323 22px with black text shadow.

| Depth  | Text |
|--------|------|
| 100m   | Your investors are still smiling |
| 300m   | WiFi lost. No one can stop you now |
| 550m   | Deeper than most military subs. Yours cost less. Coincidence? |
| 800m   | Sunlight is for poor people |
| 1050m  | The hull groans. The sommelier says it's fine. |
| 1300m  | Insurance expired 300m ago |
| 1600m  | A rivet pings off the wall. You call it 'ambient music.' |
| 1900m  | The viewport fogs. From the outside. |
| 2100m  | That sound? Applause. It's the rivets leaving. |
| 2400m  | Bluetooth controller disconnects. Was always Bluetooth. |
| 2650m  | Water drips from the ceiling. 'Feature, not a bug.' |
| 2900m  | Hull cracks are now a design feature |
| 3050m  | The viewport cracks. You call it 'character.' |
| 3200m  | Hubris: CRITICAL |
| 3300m  | 'All good here.' |
| 3346m  | PHYSICS WOULD LIKE A WORD |

---

## Waivers

Pop up periodically during descent. First appears at 600–1000m, then every
400–900m after that. Game freezes while a waiver is displayed. Dismissed by
tap/click (captured via `pointerdown` to prevent the dismiss from counting
as dive input). Maximum 7 waivers per game:

1. "WAIVER: I understand this sub was inspected by vibes alone."
2. "WAIVER: 'Pressure-tested' means the CEO sat on it once."
3. "WAIVER: Emergency exits are purely decorative."
4. "WAIVER: Hull material was chosen for aesthetics."
5. "WAIVER: 'Unsinkable' was marketing, not engineering."
6. "WAIVER: I waive my right to blame anyone worth over $1B."
7. "WAIVER: The oxygen is artisanal and limited edition."

Rendered as a centered modal: dark background (#1a1a2e), red border (#ff4444),
pink text (#ff8888), with "[ TAP TO ACCEPT ]" at the bottom in Press Start 2P.

---

## Water Color Progression

Linear interpolation between depth-keyed color zones. Both water background
and wall fill use this system (walls are 18R/18G/14B darker than water).

| Depth   | Color                  | Description      |
|---------|------------------------|------------------|
| 0m      | rgb(26, 180, 216)      | Pristine island blue |
| 400m    | rgb(14, 127, 168)      | Mid blue         |
| 1000m   | rgb(6, 50, 90)         | Deep blue        |
| 1750m   | rgb(15, 70, 30)        | Dark green       |
| 2500m   | rgb(55, 38, 15)        | Brown            |
| 2900m   | rgb(85, 75, 12)        | Murky yellow     |
| 3200m   | rgb(100, 25, 130)      | Bright purple    |
| 3346m   | rgb(70, 10, 90)        | Deep purple      |

---

## Sea Walls

### Generation
- Generated procedurally per 4px vertical segment.
- Start at GAME_W − 30 (5px inset from each side on a 1000px-max game area).
- Gradually narrow toward 22% of starting width by 5500m.
- Center position wanders with pull-toward-center bias (0.8% per segment).

### Volatility (Edge Roughness)
Jitter and wander multiply by a volatility factor that doubles at thresholds:

| Depth Range | Volatility |
|-------------|------------|
| 0–749m      | 1×         |
| 750–1499m   | 2×         |
| 1500–2499m  | 4×         |
| 2500m+      | 8×         |

### Minimum Width
- Walls never narrow below `SUB_W × 1.5 + 20` pixels (minimum passable gap
  plus margin).

### Visual
- Fill: `getWallColor(depth)` — same color system as water, 18R/18G/14B darker.
- Edge highlight: `rgba(255,255,255,0.15)`, 3px wide on each wall edge.

---

## Obstructions

### Spawning
- Begin at 500m with chance `0.004 + (depth − 500) × 0.000003` per segment.
- After 2000m, gated by the band system (see Encounter Bands below).
- Minimum vertical spacing: 2.5× sub height (35px) between obstructions.
- Width capped so remaining gap is always ≥ SUB_W × 1.5 (sub + 50% margin).
- Placement validated: at least one side must have ≥ MIN_GAP clearance.
- Rejected silently if validation fails.

### Visual
- Fill color matches wall color at spawn depth via `getWallColor(spawnDepth)`.
- Edges are jagged polygons generated at spawn time with per-vertex jitter
  scaled by the wall volatility at that depth.
- Edge highlight: `rgba(255,255,255,0.15)`, 2px stroke, matching wall style.

### Collision
- Uses bounding box (x, y, w, h) — not the visual polygon.
- Deals 1 hull damage and bounces the sub away.

---

## Fish (White, Passive)

- Up to 12 on screen at a time.
- Spawn from offscreen left or right with random vertical offset.
- Drift horizontally at base speed with gentle vertical bob.
- **Avoidance**: within 80px of the sub, fish steer away proportionally.
- Cannot damage the sub.
- Drawn as white (`rgba(255,255,255,0.7)`) silhouettes with animated tail
  (sin-wave phase) and a dark eye dot.

---

## Sharks (Red, Hostile)

### Spawning
- Appear only below 2000m, gated by the band system.
- 1–3 per band, minimum 80m vertical spacing between sharks.
- Patrol speed: 0.5–1.1 px/frame, random initial direction.
- Size: 8–14px base.

### Behavior
- Patrol left-right between wall bounds at their spawn depth.
- Reflect off wall edges (leftBound/rightBound, 15px inset from walls).
- Reflect off obstructions at the same depth (checks vertical overlap
  and reverses horizontal velocity on contact).
- Neither seek nor avoid the sub — purely predictable.

### Collision
- Bounding circle check (halfSk = size × 0.6).
- Deals 1 hull damage and bounces the sub away, same as walls/obstructions.
- No damage at depth ≤ 0m.

### Visual
- Bright red body (`rgba(240,55,55,0.95)`), drawn as a pointed oval.
- Dorsal fin triangle on top.
- Animated tail fin (sin-wave at gameTime × 8).
- Yellow eye (`rgba(255,220,100,0.9)`).

---

## Encounter Bands (2000m+)

Every 325m after 2000m, the game rolls one of four equally-weighted outcomes:

| Roll | Band Type          | Contains           |
|------|--------------------|--------------------|
| 0    | Obstructions only  | Obstructions, no sharks |
| 1    | Sharks only        | Sharks, no obstructions |
| 2    | Both               | Obstructions + sharks |
| 3    | Open ocean         | Neither            |

Below 2000m, obstructions spawn freely (no band gating). Sharks never appear
below 2000m.

---

## Hull Integrity

- 3 points, displayed as sub-shaped icons in the upper-left HUD.
- Filled icons: green (#33ff99) with glow. Empty: green outline (#33ff9944).
- Each hit (wall, obstruction, shark) costs 1 point.
- On hit: 1.8s invulnerability with blink animation, horizontal bounce.
- At 0 points: implosion triggered.
- Visual damage on sub hull: red crack lines appear at HP < 3, additional
  cracks at HP < 2.

---

## Crush Depth Sequence (3,346m)

1. A dashed red line appears between walls at 3,346m depth, labeled
   "— 3346m — CRUSH DEPTH —". Pulses with `sin(gameTime × 4)` opacity.
2. When the sub reaches 3,346m, game enters "crushing" state.
3. Hull pips pop one at a time, 0.6 seconds apart, with a white flash
   (alpha 0.35) and escalating screen shake (4 + pops × 3).
4. Always pops all 3 pips regardless of current HP.
5. After all pips: 0.5 second pause, then full implosion.

---

## Implosion Animation

- 80 confetti particles: random colors (#ff4444, #ffcc00, #33ff99, #ff88ff,
  #44aaff, #ffffff), expanding outward with gravity and friction.
- 25 metal debris particles: grey (#8899aa), expanding with gravity.
- Bubble burst: random bubbles spawn from implosion center.
- White flash: alpha 1→0 over 0.3 seconds.
- Screen shake: starts at 6–10, decays over 2.5 seconds.
- Sub hidden after 0.12 seconds of implosion.
- Game-over screen appears after 2.5 seconds.

---

## Submarine Visual

- Body: bright yellow ellipse (#f0cc22), highlight (#ffe944) on upper half.
- Viewport: dark blue circle (#224466) with lighter inner (#336688).
- Conning tower: yellow rectangle (#ddcc33) on top.
- Propeller: two animated lines on the rear, faster when diving (16×) vs
  idle (6× gameTime).
- Dive prompt (when not diving): white dotted circle (2.5px, dash [5,5])
  below sub with down-arrow inside. Pulses opacity 0.5 ± 0.2 at 3Hz.

---

## HUD

### Upper Left: Hull Integrity
- 3 sub-shaped icons, 28px apart.
- Filled (green with glow) for remaining HP, outlined for lost HP.

### Upper Right: Depth
- White, bold 26px VT323 with black text shadow.
- Shows `{depth}m`, floored integer, clamped to ≥ 0.

### Upper Right (below depth): Dollars Wasted
- `${depth × 47}/sec` in 15px VT323, 50% white opacity.

### Center: Milestone Text
- Yellow (#ffcc00) 22px VT323, centered, with black text shadow.
- Fades in over 0.5s, holds 2.2s, fades out over 0.5s.

### Center: Waiver Modal
- Overlay: `rgba(0,0,0,0.55)` full screen.
- Box: max 400px wide, dark fill, red border, word-wrapped text.

### Bottom Center: Dive Hint (depth < 50m)
- "HOLD TO DIVE ▼" and "◀ ▶ TO STEER" in 15px VT323.
- Pulses opacity at 3Hz. Only visible in playing state, not during waivers.

---

## Surface Visual

- Animated wave lines: 3 rows of sine-wave strokes at the water surface.
  - Two overlapping frequencies: `sin(x×0.02 + phase)` and `sin(x×0.05 + phase×0.7)`.
  - Amplitude decreases per row (3, 2.2, 1.4px).
  - Opacity decreases per row (0.5, 0.35, 0.2).
  - White stroke, 2px line width.
- Black sky (#111) fills above the wave line.
- Surface fade (loss): white overlay, opacity increases at dt × 0.6.

---

## Screen Shake

- Below 2800m: `min(4, (depth − 2800) / 150)`.
- During crushing: `4 + crushPops × 3`.
- During implosion: `max(6, 10 − implosionTimer × 3)`.
- Applied as random canvas translate before drawing, restored after.

---

## Title Screen

- Background: linear gradient from island blue (#1ab4d8) to deep blue (#064a6e).
- Title: "IMPLODE" in Press Start 2P, red (#ff4444) with pulsing text shadow.
- Tagline: "The only losing move is making it back alive!" in VT323, light yellow.
- Captain's Log: "Skipped the inspection. Vibes are immaculate. The hull is
  certified by my gut feeling. Full speed down." in VT323, light cyan.
- DESCEND button: red (#ff4444) with 3D shadow, Press Start 2P.
- HIGH SCORES button: green (#1a8a5a), smaller.

---

## Forbes Abyss List (High Scores)

### Storage
- Shared persistent storage (`window.storage`, `shared: true`).
- Key: `leaderboard-v2`.
- Maximum 10 entries, sorted by depth ascending (shallowest = best).

### Seed Scores
Populated on first launch and after most resets:

| Rank | Initials | Depth  |
|------|----------|--------|
| 1    | GSA      | 105m   |
| 2    | STV      | 457m   |
| 3    | FSH      | 1907m  |
| 4    | JFF      | 2614m  |
| 5    | MSK      | 3346m  |

### Display
- Title: "FORBES ABYSS LIST" in Press Start 2P, yellow.
- Rows: rank (yellow), initials (green), depth (pink/red), in VT323.
- Empty state: "No scores yet. Go fail gloriously."
- BACK button returns to title.

### Initials Entry
- Shown when player's depth qualifies for top 10 (and depth > 0).
- 3 letter boxes with up/down/next navigation arrows.
- Letters cycle A–Z. Active box blinks yellow.

### Unplug Cabinet (Reset)
- Button labeled "UNPLUG CABINET" appears in the lower-left of the scores
  screen, but **only** when:
  - The board has 10 scores, AND
  - It is every 3rd time the scores screen is shown (session counter, resets
    on page reload).
- On press: CRT shutoff animation plays:
  1. Screen squeezes vertically to a horizontal phosphor line (~1s).
  2. Line contracts to a center dot (~0.6s).
  3. Dot fades with afterglow (~0.4s).
  4. Pure black screen for 10 seconds.
  5. Title screen reappears.
- Scores are reset. 2/3 chance: reseeded with default scores. 1/3 chance:
  completely blank (Easter egg — shows empty-state text).

---

## Input

### Touch
- `touchstart`: sets `inputDown=true`, records X position.
- `touchmove`: updates X position.
- `touchend`: sets `inputDown=false`, clears X.
- All touch events call `preventDefault()` to block scroll/zoom.

### Mouse
- `mousedown`/`mousemove`/`mouseup` mirror touch behavior.
- Suppressed when `usingTouch=true` (one-way latch on first touch event)
  to prevent double-processing from emulated mouse events.

### Keyboard
- Arrow keys, WASD, spacebar tracked via `keydown`/`keyup`.
- Down/S/Space = dive. Left/A, Right/D = steer.

### Waiver Dismiss
- `pointerdown` with capture phase intercepts before dive input.
- Suppresses `inputDown` to prevent the dismiss tap from counting as diving.

---

## Game States

| State      | Description                                    |
|------------|------------------------------------------------|
| `title`    | Title screen displayed, game loop not running  |
| `playing`  | Active gameplay                                |
| `crushing` | At crush depth, hull pips popping sequentially |
| `imploding`| Implosion animation playing                    |
| `gameover` | Game-over or initials screen displayed          |
| `survived` | Survival/shame screen displayed                |

---

## Rendering Order

1. Background water fill
2. Sky and wave lines (when near surface)
3. Walls (with crush depth line)
4. Obstructions
5. Fish
6. Sharks
7. Bubbles
8. Submarine (hidden during late implosion)
9. Confetti and debris particles
10. White flash overlay
11. Surface fade overlay
12. HUD (hull, depth, milestones, waivers, dive hint)

---

## Fonts

- **Press Start 2P**: titles, buttons, initials, waiver accept text.
- **VT323**: body text, HUD, milestones, waivers, scores, captain's log.
- Loaded via Google Fonts.

---

## Game Area

- Canvas fills viewport.
- Game area capped at 1000px wide, centered horizontally.
- Walls, obstructions, and sharks spawn within the game area.
- Sub clamped to game area ± SUB_W from edges.

---

## Bubbles

- Spawn from the sub when diving (20% chance per frame).
- Small circles (1–4px radius), white-cyan stroke, no fill.
- Rise upward with slight horizontal drift.
- Fade out over time (alpha -= 0.008/frame).
- Also spawn from implosion center during implosion animation.

---

## Canonical Drawing Code (Canvas 2D)

Extracted verbatim from the HTML source. These are the authoritative
rendering implementations — use them to validate visual fidelity in ports.

Constants referenced below:

```js
const SUB_W = 28, SUB_H = 14;
```

### Color Functions

```js
function getWaterColor(d) {
  const zones = [
    {d:0,    r:26, g:180,b:216},
    {d:400,  r:14, g:127,b:168},
    {d:1000, r:6,  g:50, b:90},
    {d:1750, r:15, g:70, b:30},
    {d:2500, r:55, g:38, b:15},
    {d:2900, r:85, g:75, b:12},
    {d:3200, r:100,g:25, b:130},
    {d:3346, r:70, g:10, b:90},
  ];
  if(d<=0) return zones[0];
  if(d>=zones[zones.length-1].d) return zones[zones.length-1];
  for(let i=0;i<zones.length-1;i++){
    if(d>=zones[i].d && d<zones[i+1].d){
      const t=(d-zones[i].d)/(zones[i+1].d-zones[i].d);
      return {
        r:Math.floor(zones[i].r+(zones[i+1].r-zones[i].r)*t),
        g:Math.floor(zones[i].g+(zones[i+1].g-zones[i].g)*t),
        b:Math.floor(zones[i].b+(zones[i+1].b-zones[i].b)*t),
      };
    }
  }
  return zones[zones.length-1];
}

function getWallColor(d) {
  const c=getWaterColor(d);
  return {r:Math.max(0,c.r-18), g:Math.max(0,c.g-18), b:Math.max(0,c.b-14)};
}
```

### Submarine

Drawn at origin after `ctx.translate(subX, subY)`. Includes dive prompt,
hull body, viewport, conning tower, animated propeller, and damage cracks.

```js
function drawSubmarine(){
  if(invulnTimer>0&&Math.sin(blinkPhase*Math.PI)>.3)return;
  ctx.save();ctx.translate(subX,subY);

  // Dive prompt: dotted circle below sub when not diving
  if(!diving&&state==='playing'){
    ctx.save();
    ctx.setLineDash([5,5]);
    ctx.strokeStyle='rgba(255,255,255,'+(0.5+Math.sin(gameTime*3)*0.2)+')';
    ctx.lineWidth=2.5;
    ctx.beginPath();ctx.ellipse(0,SUB_H+22,20,20,0,0,Math.PI*2);ctx.stroke();
    ctx.setLineDash([]);
    ctx.lineWidth=2.5;
    ctx.beginPath();ctx.moveTo(0,SUB_H+14);ctx.lineTo(0,SUB_H+30);
    ctx.moveTo(-6,SUB_H+24);ctx.lineTo(0,SUB_H+31);ctx.lineTo(6,SUB_H+24);
    ctx.stroke();
    ctx.restore();
  }

  // Body
  ctx.fillStyle='#f0cc22';
  ctx.beginPath();ctx.ellipse(0,0,SUB_W/2,SUB_H/2,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#ffe944';
  ctx.beginPath();ctx.ellipse(0,-2,SUB_W/2-4,SUB_H/2-5,0,Math.PI,Math.PI*2);ctx.fill();

  // Viewport
  ctx.fillStyle='#224466';
  ctx.beginPath();ctx.arc(SUB_W/2-7,-1,3.5,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#336688';
  ctx.beginPath();ctx.arc(SUB_W/2-7,-2,1.8,0,Math.PI*2);ctx.fill();

  // Tower
  ctx.fillStyle='#ddcc33';ctx.fillRect(-3,-SUB_H/2-5,6,6);

  // Propeller (animated)
  const pp=gameTime*(diving?16:6);
  ctx.strokeStyle='#887744';ctx.lineWidth=1.5;
  ctx.beginPath();
  ctx.moveTo(-SUB_W/2,-3*Math.sin(pp));
  ctx.lineTo(-SUB_W/2-5,-5*Math.sin(pp));
  ctx.moveTo(-SUB_W/2,3*Math.sin(pp+1));
  ctx.lineTo(-SUB_W/2-5,5*Math.sin(pp+1));
  ctx.stroke();

  // Damage cracks
  if(hullHP<3){
    ctx.strokeStyle='rgba(255,100,100,0.7)';ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(-7,-3);ctx.lineTo(-1,2);ctx.lineTo(4,-1);ctx.stroke();
  }
  if(hullHP<2){
    ctx.beginPath();ctx.moveTo(5,-4);ctx.lineTo(9,0);ctx.lineTo(7,3);ctx.stroke();
  }

  ctx.restore();
}
```

### Fish (White, Passive)

Drawn at origin after translate/scale. `s` = fish size (4–10px), `f.tailPhase`
animates the tail. Faces right at scale(1,1), left at scale(-1,1).

```js
// Per fish: ctx.translate(f.x, f.y); ctx.scale(facing, 1);
const s = f.size;

// Body (two quadratic curves forming a leaf shape)
ctx.fillStyle='rgba(255,255,255,0.7)';
ctx.beginPath();
ctx.moveTo(s,0);
ctx.quadraticCurveTo(s*0.3,-s*0.5,-s*0.2,0);
ctx.quadraticCurveTo(s*0.3,s*0.5,s,0);
ctx.fill();

// Tail (triangle, animated)
const tailSwing=Math.sin(f.tailPhase)*s*0.35;
ctx.beginPath();
ctx.moveTo(-s*0.2,0);
ctx.lineTo(-s*0.7,tailSwing-s*0.3);
ctx.lineTo(-s*0.7,tailSwing+s*0.3);
ctx.closePath();
ctx.fill();

// Eye
ctx.fillStyle='rgba(0,0,0,0.5)';
ctx.beginPath();
ctx.arc(s*0.55,-s*0.08,s*0.1,0,Math.PI*2);
ctx.fill();
```

### Shark (Red, Hostile)

Drawn at origin after translate/scale. `s` = shark size (8–14px). Same
facing convention as fish. Tail animates at `gameTime*8`.

```js
// Per shark: ctx.translate(sk.x, screenY); ctx.scale(facing, 1);
const s = sk.size;

// Body
ctx.fillStyle='rgba(240,55,55,0.95)';
ctx.beginPath();
ctx.moveTo(s*1.2,0);
ctx.quadraticCurveTo(s*0.4,-s*0.55,-s*0.4,0);
ctx.quadraticCurveTo(s*0.4,s*0.55,s*1.2,0);
ctx.fill();

// Dorsal fin
ctx.beginPath();
ctx.moveTo(s*0.3,-s*0.3);
ctx.lineTo(s*0.1,-s*0.8);
ctx.lineTo(-s*0.15,-s*0.3);
ctx.closePath();
ctx.fill();

// Tail fin (animated)
const tp=gameTime*8;
const ts=Math.sin(tp)*s*0.2;
ctx.beginPath();
ctx.moveTo(-s*0.4,0);
ctx.lineTo(-s*0.9,ts-s*0.4);
ctx.lineTo(-s*0.9,ts+s*0.4);
ctx.closePath();
ctx.fill();

// Eye
ctx.fillStyle='rgba(255,220,100,0.9)';
ctx.beginPath();
ctx.arc(s*0.7,-s*0.1,s*0.1,0,Math.PI*2);
ctx.fill();
```

### Obstruction (Jagged, Wall-Colored)

Drawn at origin after `ctx.translate(obs.x, screenY)`. Uses pre-generated
`edgePoints` array (each with `{t, jx}` where `t` is 0–1 across width and
`jx` is jitter scaled by wall volatility at spawn depth).

```js
const wc=getWallColor(obs.spawnDepth);
const fillCol=`rgb(${wc.r},${wc.g},${wc.b})`;
const ep=obs.edgePoints;
const hw=obs.w/2, hh=obs.h/2;

ctx.fillStyle=fillCol;
ctx.beginPath();
// Top edge: left to right with jitter
for(let i=0;i<ep.length;i++){
  const px = -hw + obs.w * ep[i].t + ep[i].jx;
  const py = -hh + ep[i].jx * 0.4;
  if(i===0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
}
// Right side down
ctx.lineTo(hw + ep[ep.length-1].jx, hh);
// Bottom edge: right to left with jitter (reversed)
for(let i=ep.length-1;i>=0;i--){
  const px = -hw + obs.w * ep[i].t - ep[i].jx * 0.7;
  const py = hh - ep[i].jx * 0.3;
  ctx.lineTo(px, py);
}
ctx.closePath();
ctx.fill();

// Edge highlight
ctx.strokeStyle='rgba(255,255,255,0.15)';
ctx.lineWidth=2;
ctx.stroke();
```

### Walls

Each wall segment is a 4px-tall row with left and right edges.

```js
const wc=getWallColor(w.y);
ctx.fillStyle=`rgb(${wc.r},${wc.g},${wc.b})`;
ctx.fillRect(0,sy,w.left,SEG_H+1);           // left wall
ctx.fillRect(w.right,sy,W-w.right,SEG_H+1);  // right wall
ctx.fillStyle='rgba(255,255,255,0.15)';
ctx.fillRect(w.left-2,sy,3,SEG_H+1);         // left edge highlight
ctx.fillRect(w.right-1,sy,3,SEG_H+1);        // right edge highlight
```

### Crush Depth Line

Pulsing dashed red line with label, drawn at world Y = 3346.

```js
ctx.save();
ctx.setLineDash([12,8]);
ctx.strokeStyle = 'rgba(255,50,50,' + (0.5 + Math.sin(gameTime * 4) * 0.25) + ')';
ctx.lineWidth = 2;
ctx.beginPath();
ctx.moveTo(w.left + 4, dangerScreenY);
ctx.lineTo(w.right - 4, dangerScreenY);
ctx.stroke();
ctx.setLineDash([]);
ctx.font = '12px "VT323",monospace';
ctx.fillStyle = 'rgba(255,80,80,' + (0.5 + Math.sin(gameTime * 4) * 0.2) + ')';
ctx.textAlign = 'center';
ctx.fillText('— 3346m — CRUSH DEPTH —', (w.left + w.right) / 2, dangerScreenY - 6);
ctx.restore();
```

### Surface Waves

Three animated sine-wave rows at the water surface (scrollOffset = 0).

```js
ctx.strokeStyle='rgba(255,255,255,0.6)';
ctx.lineWidth=2;
for(let row=0;row<3;row++){
  ctx.beginPath();
  const waveY = surfaceScreenY + row*6 - 6;
  const phase = gameTime*1.5 + row*1.2;
  const amp = 3 - row*0.8;
  for(let x=0;x<=W;x+=4){
    const y = waveY + Math.sin(x*0.02 + phase)*amp
            + Math.sin(x*0.05 + phase*0.7)*amp*0.5;
    if(x===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
  }
  ctx.globalAlpha = 0.5 - row*0.15;
  ctx.stroke();
}
```

### Bubbles

Stroke-only circles that rise and fade.

```js
ctx.beginPath();
ctx.arc(b.x, b.y, b.r, 0, Math.PI*2);
ctx.strokeStyle=`rgba(200,240,255,${b.a*0.6})`;
ctx.lineWidth=1;
ctx.stroke();
```

### HUD — Hull Integrity Icons

Three sub-shaped icons, 28px apart, starting at (12, 16).

```js
for(let i=0;i<3;i++){
  const x=12+i*28, y=16;
  if(i<hullHP){
    // Filled
    ctx.fillStyle='#33ff99';
    ctx.shadowColor='#33ff9966';ctx.shadowBlur=4;
    ctx.beginPath();ctx.ellipse(x+9,y,10,5,0,0,Math.PI*2);ctx.fill();
    ctx.fillRect(x+5,y-8,4,5);
    ctx.shadowBlur=0;
  }else{
    // Empty
    ctx.strokeStyle='#33ff9944';ctx.lineWidth=1;
    ctx.beginPath();ctx.ellipse(x+9,y,10,5,0,0,Math.PI*2);ctx.stroke();
    ctx.strokeRect(x+5,y-8,4,5);
  }
}
```

### HUD — Depth Display

```js
ctx.font='bold 26px "VT323",monospace';
ctx.textAlign='right';
ctx.fillStyle='#fff';
ctx.shadowColor='#00000088';ctx.shadowBlur=4;
ctx.fillText(Math.floor(Math.max(0,depth))+'m', W-14, 28);
ctx.shadowBlur=0;

ctx.font='15px "VT323",monospace';
ctx.fillStyle='#ffffff77';
ctx.fillText('$'+(Math.floor(Math.max(0,depth)*47)).toLocaleString()+'/sec', W-14, 46);
```

### HUD — Milestone Popup

```js
// milestoneTimer counts down from 3.2
const a = milestoneTimer<.5 ? milestoneTimer/.5
        : (milestoneTimer>2.7 ? (3.2-milestoneTimer)/.5 : 1);
ctx.globalAlpha=Math.max(0,Math.min(1,a));
ctx.font='22px "VT323",monospace';
ctx.fillStyle='#ffcc00';
ctx.textAlign='center';
ctx.shadowColor='#00000088';ctx.shadowBlur=6;
const lines=milestoneText.split('\n');
lines.forEach((l,i)=>ctx.fillText(l, W/2, H/2-(lines.length-1)*14+i*28));
```

### HUD — Waiver Modal

```js
ctx.fillStyle='rgba(0,0,0,0.55)';ctx.fillRect(0,0,W,H);
const bw=Math.min(W-30,400), bh=120;
const bx=(W-bw)/2, by=(H-bh)/2;
ctx.fillStyle='#1a1a2e';ctx.strokeStyle='#ff4444';ctx.lineWidth=2;
ctx.fillRect(bx,by,bw,bh);ctx.strokeRect(bx,by,bw,bh);
ctx.font='16px "VT323",monospace';ctx.fillStyle='#ff8888';ctx.textAlign='center';
// Word-wrap waiverText into lines, then:
wrapLines.forEach((l,i)=>ctx.fillText(l, W/2, by+28+i*20));
ctx.font='10px "Press Start 2P",monospace';ctx.fillStyle='#ff4444';
ctx.fillText('[ TAP TO ACCEPT ]', W/2, by+bh-14);
```

### Implosion Particles

```js
// Confetti (80 pieces)
ctx.save();ctx.translate(c.x, c.y);ctx.rotate(c.rot);
ctx.globalAlpha=Math.max(0,c.a);
ctx.fillStyle=c.color; // one of: #ff4444 #ffcc00 #33ff99 #ff88ff #44aaff #fff
ctx.fillRect(-c.r, -c.r/2, c.r*2, c.r);
ctx.restore();

// Metal debris (25 pieces)
ctx.globalAlpha=Math.max(0,p.a);
ctx.fillStyle='#8899aa';
ctx.fillRect(p.x-p.r/2, p.y-p.r/2, p.r, p.r);
```
