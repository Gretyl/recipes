# PROMPTS — IMPLODE

Append new prompts to the bottom. Never edit history.

---

## v1.0 — seed

**Prompt:** Unrecoverable. The v1.0 artifact shipped to
https://gretyl.maplecrew.org/implode.html before the originating prompt
was preserved in this repo.

**Authoritative behavioral spec going forward:**
`docs/implode/IMPLODE-design-bible.md` — documents every physics
constant, state transition, depth milestone, encounter band, and
canonical drawing routine the v1.0 build exhibits. All future iteration
prompts should cite the design bible as the source of truth for
existing behavior and list the specific sections they intend to change.
