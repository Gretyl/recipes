# IMPLODE

An inverted-objective submarine game: you pilot a sub downward through
progressively hostile water until you're crushed at 3346m — the Titan
submersible's real-world collapse depth. Surviving the descent is failure.
Reaching crush depth, with your initials carved into the Forbes Abyss
leaderboard, is the win condition.

## Status

Stable — v1.0 shipped to https://gretyl.maplecrew.org/implode.html.

## Authoritative spec

The v1.0 prompt is unrecoverable. `docs/implode/IMPLODE-design-bible.md`
is the authoritative behavioral reference going forward — every physics
constant, state transition, depth milestone, encounter band, and
canonical drawing routine is documented there. The accompanying
`docs/implode/implode-sprite-reference.png` is its visual companion.
