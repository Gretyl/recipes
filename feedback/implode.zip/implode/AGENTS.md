# AGENTS.md

Agent-behavior guidance for this repo. Repo docs live in `docs/` — this
file covers only what agents need that has no home there. If a topic
belongs in `docs/authoring.md` or `docs/verification.md`, edit those
instead of restating them here.

## Read these first

| You're about to… | Read |
|---|---|
| Add, modify, or understand an artifact's shape | `docs/authoring.md` |
| Run verify / test / build, or decide whether to add tests | `docs/verification.md` |
| List an artifact in the gallery | `docs/manifest.yml` (format comment at the top) |
| Understand customizations to an existing artifact | `notes-<slug>.md` at repo root (e.g., `notes-implode.md`) |
| Know what's next / deferred | `TODO.md` |

## Commit & PR workflow

- **Subjects use Conventional Commits.** Pick a scope that matches the
  change surface (`implode`, `tooling`, `repo`, `scaffold`, `gallery`,
  `deps`). Drop the scope when the change is genuinely cross-cutting.
- **One concern per commit.** Atomic commits make the PR narrative walk
  cleanly for a reviewer and keep reverts surgical.
- **Feature branch per change set.** Don't commit to `main` directly.
  Branch from `origin/main`, commit on the branch, open a PR.
- **PR body is a commit-by-commit narrative.** For each commit in
  scope, write a short section that explains the *why*. A reviewer
  should be able to walk the diff unit-by-unit without guessing.

## Per-artifact ledger: `notes-<slug>.md`

When homing a new artifact or making non-trivial changes to an existing
one, record the decisions in a root-level `notes-<slug>.md` (pattern
established by `notes-implode.md`). The ledger captures:

- Where each input file landed and why.
- Divergences from template defaults, with rationale.
- Deferred work and known dangling items.
- Upstream-feedback candidates — things we fixed downstream that the
  template could adopt.

This is the *customization ledger*, not a second README. If the
content is permanent repo documentation, it belongs in `docs/` instead.

## Scope discipline

- **Don't add tests proactively.** `docs/verification.md` is explicit:
  add a spec the first time a regression would have caught something.
- **Don't duplicate `docs/` into notes files.** If a rule or convention
  is repo-wide, edit `docs/`. Notes are for per-artifact customization.
- **Ask before touching shared surface.** The shared harness
  (`shared/harness/`), CI workflow (`.github/workflows/`), root configs
  (`Makefile`, `tsconfig.json`, `vitest.config.ts`, `.htmlvalidate.json`,
  `package.json`/`package-lock.json`) and ignore rules (`.gitignore`)
  affect every artifact. Change them only when the task requires it or
  the user has asked.
