# Artemis Trail

Command Orion "Integrity" on humanity's first crewed moonshot — a
CRT-themed, single-file interactive-fiction sim of the real-life
Artemis II mission, hosted as the canonical artifact of this
`artifact-bench` instance. One HTML file, inline CSS + JS, no
bundler.

Deployed at <https://gretyl.maplecrew.org/artemis-trail.html>.

## Layout

```
AGENTS.md                   # agent-facing conventions
CLAUDE.md                   # one-line delegation: @AGENTS.md
README.md                   # you are here
notes-artemis.md            # homing log + upstream feedback
docs/
├── authoring.md            # how artifact-bench artifacts are authored (generic)
├── verification.md         # verify + test + build loop (generic)
├── manifest.yml            # gallery entry (lists Artemis Trail)
└── artemis-trail/
    └── design-bible.md     # full design spec + v1.0→v1.2 changelog
src/
└── artemis-trail/
    ├── artifact.html       # the shipping file, v1.2
    ├── README.md           # what it is, current status
    ├── PROMPTS.md          # provenance + iteration log
    └── tests/              # unit.spec.ts (planned)
```

`public/` mirrors the deploy URL directly: `make build` copies
`src/artemis-trail/artifact.html` to `public/artemis-trail.html`,
served from `https://gretyl.maplecrew.org/artemis-trail.html`.

## Quickstart

```bash
make install   # npm install
make verify    # static checks (structure, types, html)
make test      # runtime checks (unit)
make build     # src/artemis-trail/artifact.html -> public/
make ci        # verify && test && build
```

## Publishing

The deliverable for this repo is `public/artemis-trail.html`,
produced by `make build`. The `public/` tree mirrors the deploy URL
directly, so `public/artemis-trail.html` is what ends up at
`https://gretyl.maplecrew.org/artemis-trail.html`.

`make build` does **not** stage the external references
`artifact.html` carries — service worker, PWA manifest,
apple-touch-icon, OG image, Google Analytics tag. On the Gretyl
deploy these resolve because the hosting layer provides them; in
a sandbox or off-deploy context they 404 silently and the artifact
still runs (game logic is self-contained). A planned `make dist`
target, tracked in
[`notes-artemis.md`](notes-artemis.md) § "External asset
dependencies", will stage or rewrite them for truly
self-contained redistribution.

## Extending

This repo is Artemis Trail's canonical home — one homed artifact,
one deploy URL. If you want to add a **derivative** (minigame,
level editor, debug harness split out as its own HTML so it stays
copy-pasteable), see [`docs/authoring.md`](docs/authoring.md) for
the directory + required-files convention. Unrelated artifacts —
a todo app, a data viz, a different game — should live in their
own `cookbook/artifact-bench` punch-out, not here.

## Verifying changes

See [docs/verification.md](docs/verification.md). Two layers: fast
static checks via `make verify`, runtime jsdom checks via
`make test`. Add tests opt-in, the first time you catch a regression
you wish you'd caught automatically.

## CI

The project ships with a GitHub Actions workflow at `.github/workflows/ci.yml` that runs the fast verify gate on every pull request and on push to `main`:

1. `npm ci`
2. `make verify` — structure + types (tsc `--checkJs`) + html-validate
3. `make test-unit` — vitest/jsdom unit specs

No browser binaries — the job completes in under a minute. End-to-end (browser) tests are planned for a future release via a lightweight rodney-based replacement; see [`notes-artemis.md`](notes-artemis.md) § "Deferred" for status.

To run the same gate locally:

```bash
npm install && make verify && make test-unit
```

```mermaid
flowchart LR
    A[PR or push to main] --> B[npm ci]
    B --> C[make verify]
    C --> D[make test-unit]
    D --> E{Pass?}
    E -->|Yes| F[Green]
    E -->|No| G[Red]
```
