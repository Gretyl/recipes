# Prompts — artemis-trail

A running log of the prompts that produced this artifact, in order.
Append new prompts at the bottom; never edit history. The point is
provenance: another author should be able to read this file and
understand how the artifact got to its current shape.

---

## 0. Homed at v1.2

Artemis Trail was authored outside artifact-bench and reaches this
repository already at v1.2. The per-version changelog (v1.0 → v1.2)
lives in `docs/artemis-trail/design-bible.md` Appendix A; the seed
prompts and iteration log from that pre-homing period are not
reproduced here.

Future iteration prompts — anything that modifies `artifact.html` from
v1.2 forward — should be appended below as numbered sections.
