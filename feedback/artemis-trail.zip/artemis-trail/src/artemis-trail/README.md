# artemis-trail

The Artemis Trail — a CRT-themed, single-file interactive fiction game
putting the player in command of the Orion capsule "Integrity" on the
real-life Artemis II crewed lunar flyby. Play unfolds across 10 days ×
3 shifts (30 total), mixing resource management, scripted milestones
(launch, toilet malfunction, TLI burn, distance record, lunar flyby,
re-entry, splashdown), random event pools, and choice dilemmas against
a 24-hour signal-delay arc back from the Moon.

Single-file, self-contained HTML; no bundler. Runtime dependencies:

- Google Fonts (VT323, Press Start 2P) — degrades gracefully to system
  monospace when unreachable.
- Google Analytics gtag — optional; harmless in sandboxed renders.

No `window.storage` use; session state is ephemeral. Design spec lives
at `docs/artemis-trail/design-bible.md`.

## Status

Homed at v1.2. Per-version history (v1.0 → v1.2) is preserved in
`docs/artemis-trail/design-bible.md` Appendix A. The inline script
carries `// @ts-nocheck`; a JSDoc retrofit and the unit + integration
test suite will land in a follow-up instrumentation pass.
