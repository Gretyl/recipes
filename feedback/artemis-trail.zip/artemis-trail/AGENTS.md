# AGENTS.md

Orientation and conventions for AI coding agents working in this
repository. Humans: start with [`README.md`](README.md).

## What this repo is

A `cookbook/artifact-bench` instance (from Gretyl/recipes) hosting
**Artemis Trail v1.2** as its single canonical artifact. Source at
`src/artemis-trail/`; design spec at
`docs/artemis-trail/design-bible.md`.

## Read in order

1. [`README.md`](README.md) — workbench overview, layout, quickstart.
2. [`docs/authoring.md`](docs/authoring.md) — artifact structure and
   lifecycle.
3. [`docs/verification.md`](docs/verification.md) — verify + test +
   build loop.
4. [`notes-artemis.md`](notes-artemis.md) — current artifact's
   customization log, deferred work, and upstream feedback for the
   template recipe.

This document doesn't restate what those files already cover. When a
convention is already written somewhere, link to it rather than
duplicating it — docs drift when they repeat themselves.

## Commits

Atomic Conventional Commits. One concern per commit.

- Types in rotation: `feat`, `fix`, `docs`, `chore`. Scopes optional
  but often clarifying (`feat(artemis-trail):`, `fix(ci):`).
- **No `Signed-off-by` or `Co-Authored-By` footers.** Clean trailers.
- Subject ≤ 72 chars, imperative, no trailing period.
- On feature branches, prefer many small commits over one fat commit.
- The `commit` skill captures the full rule set — invoke it before
  each commit.

## TDD stance

Every plan you draft must state TDD applicability explicitly rather
than leaving it implicit.

- **TDD applies** to new or changed code logic — game helpers,
  utilities, anything under `scripts/` or `shared/harness/`.
  Red-green-refactor against a failing `vitest` spec before
  implementation.
- **TDD does not apply** to content migrations, YAML/manifest edits,
  CHANGELOG updates, new markdown, or deleting obsolete directories.
  Those are verified by running `make verify` / `make build`
  post-commit, not by writing specs first.
- When deferring TDD, name where it lands next (e.g., "the
  test-instrumentation session picks this up"). Don't silently skip.

## Tests

- Unit spec location: `src/<artifact-slug>/tests/unit.spec.ts`.
  Discovery pattern `src/**/unit.spec.ts` in
  [`vitest.config.ts`](vitest.config.ts).
- Harness:
  [`shared/harness/load-artifact.ts`](shared/harness/load-artifact.ts)
  loads an artifact into jsdom with a `window.storage` mock from
  [`shared/harness/storage-mock.ts`](shared/harness/storage-mock.ts).
- `make test-unit` passes `--passWithNoTests` to vitest
  ([`Makefile:53`](Makefile)), so a zero-spec state is tolerated
  during the window between removing a template example's tests and
  authoring the real artifact's tests.
- Integration and e2e tests are deferred; when they return, they land
  alongside the v1.2 rodney-based harness called out in
  [`README.md`](README.md).

## File-edit etiquette

- **Prefer editing existing files over creating new ones.** New files
  should have a single clear home for their content.
- **Single source of truth.** If a rule belongs in two places, pick
  one and link from the other. This file in particular should not
  restate what the linked docs already say.
- `src/<slug>/artifact.html` inline scripts may carry `// @ts-nocheck`
  until a JSDoc retrofit lands. Don't remove the pragma without
  extracting a typed helper module and adding specs — see the
  test-instrumentation deferral in `notes-artemis.md`.

## Skills and tooling

- Invoke the `commit` skill before creating git commits.
- Use the `github` skill for anything reaching the `gh` CLI (PRs,
  checks, runs, API).
- Plan mode is expected for multi-step work (3+ steps, ambiguity,
  refactors). Simple edits can go straight to action.

## State & follow-ups

Deferred work and upstream feedback for the `cookbook/artifact-bench`
template live in [`notes-artemis.md`](notes-artemis.md). Keep
forward-looking lists in that file; don't fork them across more
files.
