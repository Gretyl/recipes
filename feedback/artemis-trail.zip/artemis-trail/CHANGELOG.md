# Changelog

All notable changes to this workbench — new artifacts, design
iterations, deploy rollouts — go here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

Per-artifact prompt history lives in `src/<artifact>/PROMPTS.md`; this
file is the repo-level ledger that spans artifacts.

## [Unreleased]

### Added

- `src/artemis-trail/` — Artemis II interactive mission sim, homed at
  v1.2. See `docs/artemis-trail/design-bible.md` for the design spec
  and Appendix A for v1.0 → v1.2 history.
- `docs/artemis-trail/design-bible.md` — full design bible for Artemis
  Trail.
- `notes-artemis.md` — customization log for the homing.

### Removed

- `src/hello-artifact/` — template example, replaced by Artemis Trail.
